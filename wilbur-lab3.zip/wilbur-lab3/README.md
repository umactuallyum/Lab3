# Wilbur Company — Lab 3 Helper (Web & Database Vulnerability Assessment)

Automation + evidence-capture helper for **MIS 689 Cyber Warfare Capstone, Lab 3**.
It wraps the standard tools the lab assigns (Hydra, SQLMap, msfvenom/Metasploit),
runs the terminal-driven steps from one config file, and saves a text transcript
**and** a screenshot for each question.

> **Authorized lab use only.** Run this only against the course's own practice
> target (`cyber.eller.arizona.edu` / the lab VM network). Using these tools
> against any system you are not explicitly authorized to test is illegal.

## What it automates vs. what you do by hand

| Phase | Automated by the script | You do (GUI) |
|------|--------------------------|--------------|
| 1 — Login | Hydra `http-post-form` run; prints the recovered password (Q1) and the exact command (Q2) | Burp capture to read the path / field names / failure text |
| 2 — Tool 1 | SQLMap `--dbs`, `--tables`, `--dump` (Q1–Q5); auto-accepts hash cracking | Save the Burp request to `request.txt` |
| 3 — Tool 2/3 | Builds `payload.php` (+ `.jpeg` copy) and `handler.rc` listener | Burp upload bypass, start `msfconsole -r handler.rc`, trigger XSS, navigate meterpreter (Q1–Q3) |

The GUI steps are inherently interactive — the script prints exactly what to do and which output to screenshot.

## Requirements

Kali (or any distro) with: `hydra`, `sqlmap`, `msfvenom` + `msfconsole` (Metasploit),
Burp Suite, Firefox, the `rockyou.txt` wordlist, and a screenshot tool
(`gnome-screenshot`, `scrot`, `maim`, or ImageMagick's `import`).

## Use

```bash
chmod +x *.sh
nano config.sh          # fill in TARGET_HOST, form fields, LHOST, etc.
./run_all.sh            # menu, or run a phase directly:
./01_login_hydra.sh
./02_sqlmap.sh
./03_msfvenom_payload.sh
```

Transcripts land in `output/<qid>.txt`; screenshots in `screenshots/<qid>.png`.
Re-run Phase 2 after you set `DB_NAME` in `config.sh` to capture Q4/Q5.

## Import to GitHub

```bash
git init -b main          # already a repo if you unzipped the full folder
git add -A
git commit -m "Lab 3 helper"
git remote add origin git@github.com:<you>/wilbur-lab3.git
git push -u origin main
```

`payload.php`, `handler.rc`, your `request.txt`, the wordlist, and everything in
`output/` and `screenshots/` are git-ignored — so your answers and the payload
never get pushed. Submit the captured evidence through D2L, not GitHub.

## Sources used (APA 7)

- Clark, K. [Kyser Clark - Cybersecurity]. (2024, November 9). *Automated SQL injection: How to use Sqlmap like a PRO* [Video]. YouTube. https://www.youtube.com/watch?v=a2Oe4I-4fdM
- ksanchezcld. (n.d.). *Hacking_Cheat_Sheet: All my hacking/pentesting notes* [Code repository]. GitHub. Retrieved November 6, 2026, from https://github.com/ksanchezcld/Hacking_Cheat_Sheet
- Lee, C. (2026, July 2). *Sqlmap cheat sheet: Commands and flags*. StationX. https://www.stationx.net/sqlmap-cheat-sheet/ (Original work published October 20, 2022)
- ManKier. (n.d.). *hydra: A very fast network logon cracker which supports many different services* [Man page]. Retrieved November 6, 2026, from https://www.mankier.com/1/hydra
- Null Byte. (2020, September 25). *How a hacker could attack web apps with Burp Suite & SQL injection* [Video]. YouTube. https://www.youtube.com/watch?v=2oeCg8bj-4U
- Pentesting.site. (2026). *Hydra cheat sheet for password attacks*. https://pentesting.site/cheat-sheets/hydra/
- *[Author/title]* [Video]. YouTube. https://www.youtube.com/watch?v=I2S0rWPuC3w — page would not load; fill in the title and channel from the video.
