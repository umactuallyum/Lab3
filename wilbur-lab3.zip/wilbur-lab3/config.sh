# shellcheck shell=bash
# =====================================================================
# config.sh  —  Fill these in from YOUR lab environment, then save.
# Everything else reads from here. Values below are placeholders/hints.
# =====================================================================

# ---- Target (from Burp + your lab network) --------------------------
# Host or IP of the Wilbur Company web server (what Hydra connects to).
TARGET_HOST="192.168.x.25"

# ---- Phase 1: login brute force (values come from the Burp capture) --
USERNAME="admin"                       # known username (from the brief)
LOGIN_PATH="/wilburcompany/login.php"  # path from the intercepted POST
USER_FIELD="username"                  # POST field name for the user
PASS_FIELD="password"                  # POST field name for the password
# Failure condition: F=<text shown on a failed login>  (or use S=<success text>)
FAIL_CONDITION="F=Login failed"
# rockyou wordlist (unzip first if needed: sudo gunzip rockyou.txt.gz)
WORDLIST="/usr/share/wordlists/rockyou.txt"

# ---- Phase 2: SQLMap -------------------------------------------------
# Save the intercepted Tool-1 request from Burp to this file first.
REQUEST_FILE="$HOME/Desktop/request.txt"
# Fill these AFTER the first SQLMap run reveals them:
DB_NAME=""                             # e.g. wilburcompany
USERS_TABLE="users"

# ---- Phase 3: payload + listener ------------------------------------
LHOST="192.168.x.x"                    # YOUR attacking machine IP
LPORT="4444"
