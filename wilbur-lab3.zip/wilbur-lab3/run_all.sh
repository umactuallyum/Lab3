#!/usr/bin/env bash
# Menu launcher for the Wilbur Company Lab 3 helper.
# AUTHORIZED LAB USE ONLY — University of Arizona MIS 689, against the
# course's own practice target. Do not point these tools at any system
# you are not explicitly authorized to test.
set -uo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

cat <<'M'
======================================================================
 Wilbur Company — Lab 3 helper  (authorized lab use only)
----------------------------------------------------------------------
 1) Phase 1 — Hydra login brute force           (Q1, Q2)
 2) Phase 2 — SQLMap enumerate + dump           (Q1-Q5, Tool 1)
 3) Phase 3 — msfvenom payload + handler.rc     (Tool 2/3 setup)
 q) quit
======================================================================
M
read -rp "Select: " choice
case "$choice" in
  1) exec "$HERE/01_login_hydra.sh" ;;
  2) exec "$HERE/02_sqlmap.sh" ;;
  3) exec "$HERE/03_msfvenom_payload.sh" ;;
  q|Q) exit 0 ;;
  *) echo "Unknown option."; exit 1 ;;
esac
