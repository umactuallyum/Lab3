# shellcheck shell=bash
# =====================================================================
# lib/common.sh — shared helpers: coloured logging, output capture,
# best-effort screenshots. Sourced by every phase script.
# =====================================================================
set -uo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT_DIR="$ROOT_DIR/output"
SHOT_DIR="$ROOT_DIR/screenshots"
mkdir -p "$OUT_DIR" "$SHOT_DIR"

c_blue()  { printf '\033[1;34m%s\033[0m\n' "$*"; }
c_green() { printf '\033[1;32m%s\033[0m\n' "$*"; }
c_red()   { printf '\033[1;31m%s\033[0m\n' "$*"; }

# take_screenshot <name> -> screenshots/<name>.png  (full screen, best effort)
take_screenshot() {
  local out="$SHOT_DIR/$1.png"
  sleep 1
  if   command -v gnome-screenshot >/dev/null 2>&1; then gnome-screenshot -f "$out" ;
  elif command -v scrot            >/dev/null 2>&1; then scrot "$out" ;
  elif command -v maim             >/dev/null 2>&1; then maim "$out" ;
  elif command -v spectacle        >/dev/null 2>&1; then spectacle -b -n -o "$out" ;
  elif command -v import           >/dev/null 2>&1; then import -window root "$out" ;
  else
    c_red "[!] No screenshot tool found. Install one of: gnome-screenshot, scrot, maim, imagemagick."
    c_red "    Text transcript was still saved to output/. Screenshot the terminal manually for: $1"
    return 1
  fi
  [ -f "$out" ] && c_green "[+] Screenshot: $out"
}

# run_and_capture <qid> <title> -- <command...>
# Streams the command + its output to the terminal AND output/<qid>.txt,
# then takes a screenshot named <qid>.png.
run_and_capture() {
  local qid="$1" title="$2"; shift 2
  [ "${1:-}" = "--" ] && shift
  local log="$OUT_DIR/$qid.txt"
  {
    echo "########################################################"
    echo "# $qid — $title"
    echo "# $(date)"
    echo "# command: $*"
    echo "########################################################"
  } | tee "$log"
  "$@" 2>&1 | tee -a "$log"
  local rc=${PIPESTATUS[0]}
  echo "# exit code: $rc" | tee -a "$log"
  take_screenshot "$qid" || true
  return "$rc"
}
